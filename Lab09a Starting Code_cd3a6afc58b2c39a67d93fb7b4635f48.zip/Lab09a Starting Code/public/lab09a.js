let products;
let categories;

const products_api_url = "http://localhost:3000/products";

const getProducts = () => {


}